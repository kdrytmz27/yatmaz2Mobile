package com.abdulkadir.metin7x;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.net.VpnService;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.github.megatronking.netbare.NetBare;
import com.github.megatronking.netbare.NetBareConfig;
import com.github.megatronking.netbare.gateway.DefaultVirtualGatewayFactory;
import com.github.megatronking.netbare.gateway.InterceptorFactory;
import com.github.megatronking.netbare.gateway.Request;
import com.github.megatronking.netbare.gateway.RequestChain;
import com.github.megatronking.netbare.gateway.Response;
import com.github.megatronking.netbare.gateway.ResponseChain;
import java.util.Collections;

public final class VpnActivity extends Activity {
    public static final String EXTRA_AUTO_START = "auto_start_7x";
    public static void addLauncher(android.content.Context context, LinearLayout parent) {
        Button vpnButton = new Button(context);
        vpnButton.setText("ROOTSUZ VPN / OTOMATİK 7x");
        vpnButton.setOnClickListener(view -> context.startActivity(new Intent(context, VpnActivity.class)));
        parent.addView(vpnButton);
    }
    private TextView status;
    private Button burst;
    private boolean autoStart;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        autoStart = getIntent().getBooleanExtra(EXTRA_AUTO_START, false);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(32, 32, 32, 32);
        root.setOrientation(LinearLayout.VERTICAL);
        status = new TextView(this);
        status.setText("VPN kapalı");
        root.addView(status);
        Button vpn = new Button(this);
        vpn.setText("Oyun VPN'ini başlat");
        root.addView(vpn);
        burst = new Button(this);
        root.addView(burst);
        Button overlayButton = new Button(this);
        overlayButton.setText("7x overlay panelini aç");
        root.addView(overlayButton);
        TextView info = new TextView(this);
        info.setText("Oyun açılmadan önce VPN iznini verin. Konum ve hedef algılanınca 7x otomatik vurur.");
        root.addView(info);
        updateBurst();
        vpn.setOnClickListener(v -> {
            if (NetBare.get().isActive()) {
                Attack7x.setEnabled(false);
                updateBurst();
                NetBare.get().stop();
                status.setText("VPN kapalı");
            } else {
                Intent permission = NetBare.get().prepare();
                if (permission != null) startActivityForResult(permission, 1);
                else startVpn();
            }
        });
        burst.setOnClickListener(v -> {
            Attack7x.setEnabled(!Attack7x.isEnabled());
            updateBurst();
        });
        overlayButton.setOnClickListener(v -> openOverlay());
        setContentView(root);
        if (autoStart) {
            if (NetBare.get().isActive()) {
                Attack7x.setEnabled(true);
                updateBurst();
            } else {
                Intent permission = NetBare.get().prepare();
                if (permission != null) startActivityForResult(permission, 1);
                else startVpn();
            }
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 1 && result == RESULT_OK) startVpn();
        if (request == 2 && Settings.canDrawOverlays(this)) startOverlay();
    }
    private void updateBurst() {
        burst.setText(Attack7x.isEnabled() ? "Otomatik 7x durdur" : "Otomatik 7x başlat");
    }
    private void startVpn() {
        try {
            WorldBridge.init(getApplicationContext());
            InterceptorFactory<Request, RequestChain, Response, ResponseChain> factory = Attack7x::new;
            NetBareConfig config = NetBareConfig.defaultConfig().newBuilder()
                    .addAllowedApplication("com.RGames.Romia2Mobil")
                    .setVirtualGatewayFactory(DefaultVirtualGatewayFactory.create(Collections.singletonList(factory)))
                    .build();
            NetBare.get().start(config);
            if (autoStart) {
                Attack7x.setEnabled(true);
                updateBurst();
            }
            status.setText("VPN açık — yakındaki hedefler otomatik izleniyor");
        } catch (Exception ex) {
            status.setText("VPN başlatılamadı: " + ex.getMessage());
        }
    }

    private void openOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(permission, 2);
        } else {
            startOverlay();
        }
    }

    private void startOverlay() {
        Intent intent = new Intent();
        intent.setClassName(this, "com.abdulkadir.metin.OverlayServisi");
        startForegroundService(intent);
        status.setText("Overlay açık — Kanallar bölümünde 7x başlat/durdur var");
    }
}
