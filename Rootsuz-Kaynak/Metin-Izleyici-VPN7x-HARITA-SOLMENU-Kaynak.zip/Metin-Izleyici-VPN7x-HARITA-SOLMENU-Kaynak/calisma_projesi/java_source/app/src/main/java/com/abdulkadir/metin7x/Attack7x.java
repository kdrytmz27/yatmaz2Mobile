package com.abdulkadir.metin7x;

import com.github.megatronking.netbare.gateway.Interceptor;
import com.github.megatronking.netbare.gateway.Request;
import com.github.megatronking.netbare.gateway.RequestChain;
import com.github.megatronking.netbare.gateway.Response;
import com.github.megatronking.netbare.gateway.ResponseChain;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/** One parser and outgoing TCP tunnel for each intercepted game connection. */
public final class Attack7x implements Interceptor<Request, RequestChain, Response, ResponseChain> {
    private static final String GAME_IP = "185.128.114.87";
    private static final ExecutorService ATTACK_LOOP = Executors.newSingleThreadExecutor();
    private static final ExecutorService COLLECT_LOOP = Executors.newSingleThreadExecutor();
    private static volatile Attack7x active;
    private static volatile boolean enabled;
    private static volatile boolean loopStarted;
    private static volatile long lastStatusLog;
    private static final Map<Integer, Long> PICKED_RECENTLY = new ConcurrentHashMap<>();
    private static final Map<Integer, Long> PLAYER_HITS = new ConcurrentHashMap<>();
    private final WorldBridge world;
    private final Object parser;
    private volatile Request request;
    private volatile boolean closed;
    private volatile long lastResponse;

    public Attack7x() {
        world = WorldBridge.get();
        parser = world.newParser();
        ensureLoop();
    }

    public static void setEnabled(boolean value) {
        enabled = value;
        if (value) ensureLoop();
    }

    public static void ensureLoop() {
        if (!loopStarted) {
            synchronized (Attack7x.class) {
                if (!loopStarted) {
                    loopStarted = true;
                    ATTACK_LOOP.execute(Attack7x::runAttackLoop);
                    COLLECT_LOOP.execute(Attack7x::runCollectLoop);
                }
            }
        }
    }
    public static boolean isEnabled() { return enabled; }

    private static boolean game(String ip, int port) {
        return GAME_IP.equals(ip) && port >= 30000 && port <= 30150;
    }

    @Override public void intercept(RequestChain chain, ByteBuffer buffer) throws IOException {
        if (game(chain.request().ip(), chain.request().port())) {
            request = chain.request();
            ByteBuffer copy = buffer.asReadOnlyBuffer();
            byte[] bytes = new byte[copy.remaining()];
            copy.get(bytes);
            world.feedOutgoing(parser, bytes);
        }
        chain.process(buffer);
    }

    @Override public void intercept(ResponseChain chain, ByteBuffer buffer) throws IOException {
        if (game(chain.response().ip(), chain.response().port())) {
            ByteBuffer copy = buffer.asReadOnlyBuffer();
            byte[] bytes = new byte[copy.remaining()];
            copy.get(bytes);
            long before = world.lastUpdate();
            world.feedIncoming(parser, bytes);
            if (active == this) lastResponse = System.currentTimeMillis();
            if (world.lastUpdate() > before && request != null && world.hasPosition() &&
                    (active == null || active.closed ||
                     System.currentTimeMillis() - active.lastResponse > 10000)) {
                lastResponse = System.currentTimeMillis();
                active = this;
            }
        }
        chain.process(buffer);
    }

    @Override public void onRequestFinished(Request finished) { close(); }
    @Override public void onResponseFinished(Response finished) { close(); }

    private void close() {
        closed = true;
        if (active == this) active = null;
    }

    private static void runAttackLoop() {
        Attack7x previous = null;
        long lastRound = 0;
        int previousInterval = -1;
        while (true) {
            try {
                Attack7x session = active;
                if (session != previous) {
                    previous = session;
                    lastRound = 0;
                    PLAYER_HITS.clear();
                }
                if (!enabled || session == null || session.closed || session.request == null) {
                    lastRound = 0;
                    if (enabled) statusLog("7x: oyun TCP baglantisi bekleniyor");
                    Thread.sleep(10);
                    continue;
                }
                BotSettings.Snapshot settings = BotSettings.get(App.current()).snapshot();
                if (settings.hitMs != previousInterval) {
                    previousInterval = settings.hitMs;
                    lastRound = 0;
                }
                long now = System.nanoTime();
                if (lastRound != 0 && now - lastRound < TimeUnit.MILLISECONDS.toNanos(settings.hitMs)) {
                    waitWhileRunning(session, 50);
                    continue;
                }
                // Preserve the requested all-target coverage. Match the reference R2
                // simple worker's select -> 10 ms -> hit sequence and 50 ms round pause.
                List<WorldBridge.Target> targets = session.world.targets(settings);
                if (targets.isEmpty()) {
                    statusLog("7x: saldiri menzilinde uygun hedef yok");
                    waitWhileRunning(session, 500);
                    continue;
                }
                Request tunnel = session.request;
                int sent = 0;
                for (WorldBridge.Target target : targets) {
                    if (!enabled || active != session || session.closed) break;
                    long tick = System.currentTimeMillis();
                    Long last = PLAYER_HITS.get(target.vid);
                    if (target.player && last != null && tick - last < settings.pvpMs) continue;
                    tunnel.process(ByteBuffer.wrap(R2AttackProtocol.select(target.vid)));
                    if (!waitWhileRunning(session, 10)) break;
                    tunnel.process(ByteBuffer.wrap(R2AttackProtocol.attack(target.vid)));
                    sent++;
                    if (target.player) PLAYER_HITS.put(target.vid, tick);
                }
                if (System.currentTimeMillis() - lastStatusLog >= 5000)
                    statusLog("7x: " + sent + " hedefe paket, aralik " + settings.hitMs + " ms");
                lastRound = now;
                waitWhileRunning(session, 50);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                return;
            } catch (IOException ex) {
                active = null;
            } catch (RuntimeException ex) {
                android.util.Log.e("Metin7x", "Vuruş döngüsü", ex);
                try { Thread.sleep(1000); } catch (InterruptedException stop) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    private static boolean waitWhileRunning(Attack7x session, int millis)
            throws InterruptedException {
        long end = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(millis);
        while (enabled && active == session && !session.closed) {
            long left = end - System.nanoTime();
            if (left <= 0) return true;
            TimeUnit.NANOSECONDS.sleep(Math.min(left, 50_000_000L));
        }
        return false;
    }

    private static void statusLog(String message) {
        long now = System.currentTimeMillis();
        if (now - lastStatusLog >= 5000) {
            lastStatusLog = now;
            android.util.Log.i("Metin7x", message);
        }
    }

    private static void runCollectLoop() {
        while (true) {
            try {
                Attack7x session = active;
                BotSettings.Snapshot settings = BotSettings.get(App.current()).snapshot();
                if (settings.collect && session != null && !session.closed &&
                        session.request != null) {
                    collect(session, settings, session.request, 8);
                }
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
                return;
            } catch (IOException ex) {
                active = null;
            } catch (RuntimeException ex) {
                android.util.Log.e("Metin7x", "Toplama döngüsü", ex);
                try { Thread.sleep(100); } catch (InterruptedException stop) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    private static void collect(Attack7x session, BotSettings.Snapshot settings,
                                Request tunnel, int limit) throws IOException {
        if (!settings.collect || session.closed || active != session) return;
        long now = System.currentTimeMillis();
        int sent = 0;
        for (WorldBridge.GroundItem item : session.world.groundItems(settings)) {
            if (sent >= limit || !BotSettings.get(App.current()).snapshot().collect ||
                    active != session) break;
            Long previous = PICKED_RECENTLY.get(item.vid);
            if (previous != null && now - previous < 1500) continue;
            byte[] pickup = new byte[5];
            pickup[0] = 0x0f;
            for (int b = 0; b < 4; b++) pickup[b + 1] = (byte) (item.vid >>> (8 * b));
            tunnel.process(ByteBuffer.wrap(pickup));
            PICKED_RECENTLY.put(item.vid, now);
            sent++;
        }
        if (PICKED_RECENTLY.size() > 400)
            PICKED_RECENTLY.entrySet().removeIf(entry -> now - entry.getValue() > 1500);
    }

}
