package com.abdulkadir.metin7x;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.function.Consumer;

/** A wide, scrollable settings panel; all values are saved as they change. */
final class OverlaySettingsPanel {
    private static String lastListing = "";
    private static volatile WeakReference<CheckBox> collectBox = new WeakReference<>(null);
    private OverlaySettingsPanel() { }

    private static int dp(Context c, int size) {
        return Math.round(size * c.getResources().getDisplayMetrics().density);
    }

    private static TextView text(Context c, String value, int sp) {
        TextView v = new TextView(c);
        v.setText(value);
        v.setTextSize(sp);
        v.setTextColor(Color.rgb(218, 225, 238));
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private static TextView action(Context c, String title) {
        TextView v = text(c, title, 13);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(c, 8), dp(c, 7), dp(c, 8), dp(c, 7));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(41, 53, 75));
        bg.setCornerRadius(dp(c, 5));
        v.setBackground(bg);
        return v;
    }

    private static void heading(Context c, LinearLayout root, String title) {
        TextView v = text(c, title, 16);
        v.setTextColor(Color.rgb(110, 191, 255));
        v.setPadding(0, dp(c, 12), 0, dp(c, 4));
        root.addView(v);
    }

    private static void checkbox(Context c, LinearLayout root, BotSettings state,
                                 String label, String key, boolean value) {
        CheckBox box = new CheckBox(c);
        box.setText(label);
        box.setTextSize(13);
        box.setTextColor(Color.WHITE);
        box.setChecked(value);
        if ("collect".equals(key)) collectBox = new WeakReference<>(box);
        box.setOnCheckedChangeListener((button, checked) -> {
            state.bool(key, checked);
            if ("collect".equals(key)) {
                if (checked) Attack7x.ensureLoop();
                Overlay7xControls.refreshCollectButton(c);
            }
        });
        root.addView(box);
    }

    static void refreshCollectCheckbox(Context context) {
        CheckBox box = collectBox.get();
        boolean current = BotSettings.get(context).snapshot().collect;
        if (box != null && box.isChecked() != current) box.setChecked(current);
    }

    private static void dialog(Context context, String title, String initial, boolean number,
                               Consumer<String> onSave) {
        EditText input = new EditText(context);
        input.setSingleLine(!initial.contains(","));
        input.setText(initial);
        input.setSelection(input.length());
        input.setInputType(number ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT);
        LinearLayout wrap = new LinearLayout(context);
        wrap.setPadding(dp(context, 18), 0, dp(context, 18), 0);
        wrap.addView(input);
        AlertDialog dialog = new AlertDialog.Builder(context)
                .setTitle(title).setView(wrap)
                .setPositiveButton("Kaydet", (d, button) -> onSave.accept(input.getText().toString()))
                .setNegativeButton("Vazgeç", null).create();
        Window window = dialog.getWindow();
        if (window != null) window.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
        dialog.show();
    }

    private static void number(Context c, LinearLayout root, BotSettings state, String title,
                               String key, int initial, int min, int max, int step) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = text(c, title, 12);
        row.addView(label, new LinearLayout.LayoutParams(0, dp(c, 41), 1));
        TextView minus = action(c, "−");
        TextView value = action(c, String.valueOf(initial));
        TextView plus = action(c, "+");
        row.addView(minus, new LinearLayout.LayoutParams(dp(c, 35), dp(c, 34)));
        LinearLayout.LayoutParams valueSize = new LinearLayout.LayoutParams(dp(c, 64), dp(c, 34));
        valueSize.setMargins(dp(c, 3), 0, dp(c, 3), 0);
        row.addView(value, valueSize);
        row.addView(plus, new LinearLayout.LayoutParams(dp(c, 35), dp(c, 34)));
        minus.setOnClickListener(view -> {
            int next = Math.max(min, Integer.parseInt(value.getText().toString()) - step);
            state.number(key, next);
            value.setText(String.valueOf(next));
        });
        plus.setOnClickListener(view -> {
            int next = Math.min(max, Integer.parseInt(value.getText().toString()) + step);
            state.number(key, next);
            value.setText(String.valueOf(next));
        });
        value.setOnClickListener(view -> dialog(c, title, value.getText().toString(), true, typed -> {
            try {
                int next = Math.max(min, Math.min(max, Integer.parseInt(typed.trim())));
                state.number(key, next);
                value.setText(String.valueOf(next));
            } catch (NumberFormatException ignored) { }
        }));
        root.addView(row);
    }

    private static void string(Context c, LinearLayout root, BotSettings state,
                               String title, String key, String initial) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text(c, title, 12), new LinearLayout.LayoutParams(0, dp(c, 45), 1));
        TextView value = action(c, initial.isEmpty() ? "Düzenle" : initial);
        value.setSingleLine(true);
        row.addView(value, new LinearLayout.LayoutParams(dp(c, 205), dp(c, 38)));
        value.setOnClickListener(view -> dialog(c, title,
                key.equals("playerName") ? state.snapshot().playerName : state.snapshot().filterText,
                false, typed -> {
                    state.string(key, typed);
                    value.setText(typed.isEmpty() ? "Düzenle" : typed);
                }));
        root.addView(row);
    }

    private static void filterMode(Context c, LinearLayout root, BotSettings state, int selected) {
        LinearLayout row = new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text(c, "Filtre", 12), new LinearLayout.LayoutParams(dp(c, 50), dp(c, 42)));
        String[] titles = {"Hepsi", "Sadece bunlar", "Bunlar hariç"};
        TextView[] buttons = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int mode = i;
            TextView button = action(c, titles[i]);
            button.setTextColor(i == selected ? Color.rgb(92, 207, 156) : Color.WHITE);
            LinearLayout.LayoutParams size = new LinearLayout.LayoutParams(0, dp(c, 36), 1);
            size.setMargins(dp(c, 2), 0, dp(c, 2), 0);
            row.addView(button, size);
            buttons[i] = button;
            button.setOnClickListener(view -> {
                state.number("filterMode", mode);
                for (int j = 0; j < 3; j++) buttons[j].setTextColor(j == mode ?
                        Color.rgb(92, 207, 156) : Color.WHITE);
            });
        }
        root.addView(row);
    }

    static void append(Context c, LinearLayout parent) {
        BotSettings state = BotSettings.get(c);
        BotSettings.Snapshot s = state.snapshot();
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int width = Math.min(dp(c, 442),
                c.getResources().getDisplayMetrics().widthPixels - dp(c, 38));
        root.setLayoutParams(new LinearLayout.LayoutParams(Math.max(dp(c, 160), width), -2));
        root.setPadding(dp(c, 8), 0, dp(c, 8), dp(c, 8));
        parent.addView(root);

        heading(c, root, "Hedefleme ve vuruş");
        checkbox(c, root, state, "Canavarlar", "mobs", s.mobs);
        checkbox(c, root, state, "Metin taşları", "metins", s.metins);
        heading(c, root, "7x · R2 basit mod vuruşu");
        number(c, root, state, "Saldırı menzili (ham)", "attackRange", s.attackRange, 1, 30000, 50);
        number(c, root, state, "Vuruş aralığı (ms)", "hitMs", s.hitMs, 1, 5000, 5);
        root.addView(text(c, "Tüm uygun hedefler: hedef seç → 10 ms → vur. Tur sonunda 50 ms bekler.", 11));
        checkbox(c, root, state, "⚠ Vurulabilir oyunculara vur (PvP)", "pvp", s.pvp);
        number(c, root, state, "Oyuncuya vuruş aralığı (ms)", "pvpMs", s.pvpMs, 10, 5000, 25);
        number(c, root, state, "Oyuncuya vuruş menzili (ham)", "pvpRange", s.pvpRange, 1, 30000, 50);

        heading(c, root, "Toplama");
        checkbox(c, root, state, "Otomatik topla", "collect", s.collect);
        checkbox(c, root, state, "Önce Yang", "yangFirst", s.yangFirst);
        checkbox(c, root, state, "Yalnızca bana ait / sahipsiz olanı topla", "onlyOwn", s.onlyOwn);
        string(c, root, state, "Karakter adı (sahip filtresi)", "playerName", s.playerName);
        number(c, root, state, "Toplama menzili (ham)", "pickupRange", s.pickupRange, 1, 10000, 50);
        filterMode(c, root, state, s.filterMode);
        string(c, root, state, "Eşya adı / vnum listesi", "filterText", s.filterText);

        TextView list = action(c, "Yerdekileri listele (filtreyi dene)");
        root.addView(list);
        TextView result = text(c, lastListing, 12);
        root.addView(result);
        list.setOnClickListener(view -> {
            WorldBridge world;
            try { world = WorldBridge.get(); }
            catch (IllegalStateException ex) { result.setText("Önce oyun VPN'ini başlat."); return; }
            List<WorldBridge.GroundItem> items = world.groundItems(state.snapshot());
            StringBuilder lines = new StringBuilder();
            int limit = Math.min(15, items.size());
            for (int i = 0; i < limit; i++) {
                WorldBridge.GroundItem item = items.get(i);
                lines.append(item.name).append(" [").append(item.vnum).append("] · ")
                        .append(Math.round(Math.sqrt(item.distance))).append(" ham");
                if (!item.owner.isEmpty()) lines.append(" · ").append(item.owner);
                lines.append('\n');
            }
            if (items.isEmpty()) lines.append("Filtreye uyan yerde eşya yok.");
            lastListing = lines.toString();
            result.setText(lastListing);
        });
    }
}
