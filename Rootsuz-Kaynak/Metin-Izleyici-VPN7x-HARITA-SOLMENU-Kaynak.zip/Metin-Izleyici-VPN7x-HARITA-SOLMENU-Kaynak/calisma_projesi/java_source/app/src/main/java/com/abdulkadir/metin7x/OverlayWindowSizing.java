package com.abdulkadir.metin7x;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;
import java.util.Map;
import java.lang.reflect.Field;

/** Switches the actual overlay window between a tiny ch grid and a usable settings viewport. */
public final class OverlayWindowSizing {
    private OverlayWindowSizing() { }

    private static Object read(Context service, String name) throws ReflectiveOperationException {
        Field field = service.getClass().getDeclaredField(name);
        field.setAccessible(true);
        return field.get(service);
    }

    /** All islands share one channel-cell size, including room for the buff badge. */
    public static void equalizeIslandCells(Context service) {
        try {
            Map<?, ?> cells = (Map<?, ?>) read(service, "hucreler");
            if (cells == null || cells.isEmpty()) return;
            int width = 0, height = 0;
            for (Object value : cells.values()) {
                if (!(value instanceof TextView)) continue;
                TextView cell = (TextView) value;
                int textWidth = (int) Math.ceil(Math.max(
                        cell.getPaint().measureText(cell.getText().toString()),
                        cell.getPaint().measureText("8\uD83D\uDEE1")));
                width = Math.max(width, Math.max(cell.getMinWidth(),
                        textWidth + cell.getPaddingLeft() + cell.getPaddingRight()));
                height = Math.max(height, cell.getMinHeight());
            }
            if (width <= 0 || height <= 0) return;
            for (Object value : cells.values()) {
                if (!(value instanceof TextView)) continue;
                TextView cell = (TextView) value;
                ViewGroup.LayoutParams params = cell.getLayoutParams();
                if (params != null && (params.width != width || params.height != height)) {
                    params.width = width;
                    params.height = height;
                    cell.setLayoutParams(params);
                }
            }
        } catch (ReflectiveOperationException | ClassCastException error) {
            android.util.Log.w("Metin7x", "Ada hucre olculeri eslenemedi", error);
        }
    }

    public static int miniHeight(Context service) {
        try {
            LinearLayout outer = (LinearLayout) read(service, "disKok");
            if (outer != null && outer.getChildCount() != 0) {
                int measured = outer.getChildAt(0).getHeight();
                if (measured > 0) return measured;
            }
        } catch (ReflectiveOperationException ignored) { }
        return Math.round((BotSettings.get(service).miniOpen() ? 79 : 19) *
                service.getResources().getDisplayMetrics().density);
    }

    public static void apply(Context service, boolean expanded) {
        View grid = null;
        WindowManager.LayoutParams window = null;
        int oldVisibility = View.VISIBLE;
        int oldWidth = WindowManager.LayoutParams.WRAP_CONTENT;
        int oldX = 0, oldY = 0;
        try {
            WindowManager manager = (WindowManager) read(service, "wm");
            View overlay = (View) read(service, "disKok");
            window = (WindowManager.LayoutParams) read(service, "pencere");
            if (manager == null || overlay == null || window == null) return;
            grid = (View) read(service, "kok");
            if (grid != null) oldVisibility = grid.getVisibility();
            oldWidth = window.width;
            oldX = window.x;
            oldY = window.y;
            if (grid != null) grid.setVisibility(expanded ? View.GONE : View.VISIBLE);
            DisplayMetrics display = service.getResources().getDisplayMetrics();
            int densityPadding = Math.round(24 * display.density);
            if (expanded) {
                window.width = Math.min(Math.round(460 * display.density),
                        Math.max(1, display.widthPixels - densityPadding));
                window.x = Math.max(0, Math.min(window.x,
                        display.widthPixels - window.width - densityPadding / 2));
                window.y = Math.max(0, Math.min(window.y,
                        display.heightPixels - Math.round(260 * display.density)));
            } else {
                window.width = WindowManager.LayoutParams.WRAP_CONTENT;
                window.x = OverlayDragSupport.clamp(service, window.x, false);
                window.y = OverlayDragSupport.clamp(service, window.y, true);
            }
            manager.updateViewLayout(overlay, window);
        } catch (Exception error) {
            if (window != null) {
                window.width = oldWidth;
                window.x = oldX;
                window.y = oldY;
            }
            if (grid != null) grid.setVisibility(oldVisibility);
            android.util.Log.w("Metin7x", "Overlay boyutu güncellenemedi", error);
        }
    }
}
