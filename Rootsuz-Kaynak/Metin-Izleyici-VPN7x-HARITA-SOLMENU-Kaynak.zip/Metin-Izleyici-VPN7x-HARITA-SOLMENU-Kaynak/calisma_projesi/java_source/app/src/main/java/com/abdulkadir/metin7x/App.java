package com.abdulkadir.metin7x;

import android.app.Application;
import com.github.megatronking.netbare.NetBare;

public final class App extends Application {
    private static App current;
    public static App current() { return current; }
    @Override public void onCreate() {
        super.onCreate();
        current = this;
        BotSettings.get(this);
        NetBare.get().attachApplication(this, false);
    }
}
