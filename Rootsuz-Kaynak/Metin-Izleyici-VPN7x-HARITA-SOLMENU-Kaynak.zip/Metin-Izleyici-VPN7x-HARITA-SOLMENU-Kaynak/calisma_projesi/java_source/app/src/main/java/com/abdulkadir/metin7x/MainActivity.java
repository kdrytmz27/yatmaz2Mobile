package com.abdulkadir.metin7x;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.net.VpnService;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.github.megatronking.netbare.NetBare;
import com.github.megatronking.netbare.NetBareConfig;
import com.github.megatronking.netbare.gateway.DefaultVirtualGatewayFactory;
import com.github.megatronking.netbare.gateway.InterceptorFactory;
import com.github.megatronking.netbare.gateway.Request;
import com.github.megatronking.netbare.gateway.RequestChain;
import com.github.megatronking.netbare.gateway.Response;
import com.github.megatronking.netbare.gateway.ResponseChain;
import java.util.Collections;

public final class MainActivity extends Activity {
    private TextView status;
    private Button burst;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(32, 32, 32, 32);
        root.setOrientation(LinearLayout.VERTICAL);
        status = new TextView(this);
        status.setText("VPN kapalı");
        root.addView(status);
        Button vpn = new Button(this);
        vpn.setText("Oyun VPN'ini başlat");
        root.addView(vpn);
        burst = new Button(this);
        root.addView(burst);
        updateBurst();
        vpn.setOnClickListener(v -> {
            if (NetBare.get().isActive()) {
                NetBare.get().stop();
                status.setText("VPN kapalı");
            } else {
                Intent permission = NetBare.get().prepare();
                if (permission != null) startActivityForResult(permission, 1);
                else startVpn();
            }
        });
        burst.setOnClickListener(v -> {
            Attack7x.setEnabled(!Attack7x.isEnabled());
            updateBurst();
        });
        setContentView(root);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == 1 && result == RESULT_OK) startVpn();
    }
    private void updateBurst() {
        burst.setText(Attack7x.isEnabled() ? "Otomatik 7x durdur" : "Otomatik 7x başlat");
    }
    private void startVpn() {
        try {
            WorldBridge.init(getApplicationContext());
            InterceptorFactory<Request, RequestChain, Response, ResponseChain> factory = Attack7x::new;
            NetBareConfig config = NetBareConfig.defaultConfig().newBuilder()
                    .addAllowedApplication("com.RGames.Romia2Mobil")
                    .setVirtualGatewayFactory(DefaultVirtualGatewayFactory.create(Collections.singletonList(factory)))
                    .build();
            NetBare.get().start(config);
            status.setText("VPN açık — yakındaki hedefler otomatik izleniyor");
        } catch (Exception ex) {
            status.setText("VPN başlatılamadı: " + ex.getMessage());
        }
    }
}
