package com.abdulkadir.metin7x;

/** Byte-for-byte encoding of the supplied R2 simple-mode helpers. */
final class R2AttackProtocol {
    private R2AttackProtocol() { }

    static byte[] select(int vid) {
        byte[] packet = new byte[5];
        packet[0] = 0x3d;
        putVid(packet, 1, vid);
        return packet;
    }

    static byte[] attack(int vid) {
        byte[] packet = new byte[6];
        packet[0] = 0x02;
        putVid(packet, 2, vid);
        return packet;
    }

    private static void putVid(byte[] packet, int offset, int vid) {
        for (int i = 0; i < 4; i++) packet[offset + i] = (byte) (vid >>> (8 * i));
    }
}
