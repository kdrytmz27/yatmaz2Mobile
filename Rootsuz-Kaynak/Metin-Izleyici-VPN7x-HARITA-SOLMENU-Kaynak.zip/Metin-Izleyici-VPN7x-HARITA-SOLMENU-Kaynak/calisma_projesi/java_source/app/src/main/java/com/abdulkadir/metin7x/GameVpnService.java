package com.abdulkadir.metin7x;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import com.github.megatronking.netbare.NetBareService;

public final class GameVpnService extends NetBareService {
    @Override public void onDestroy() {
        Attack7x.setEnabled(false);
        super.onDestroy();
    }
    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("vpn", "Oyun VPN", NotificationManager.IMPORTANCE_LOW));
        }
    }
    @Override protected int notificationId() { return 101; }
    @Override protected Notification createNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "vpn") : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("Metin İzleyici 7x")
                .setContentText("Oyun bağlantısı açık")
                .setOngoing(true).build();
    }
}
