# Metin İzleyici için bağımsız 7x VPN modülü

Bu kaynak proje, kullanıcının sağladığı Metin İzleyici APK'sine entegre edilen rootsuz oyun trafiği modülünü içerir. İmzalı deneme APK'si `Metin-Izleyici-VPN-7x-Telefon.apk` olarak üretildi. Android cihazda ve gerçek oyun oturumunda **henüz test edilmedi**. Kaynak ZIP'i APK olarak yüklemeyin.

## İstenen akışın uygulanan kısmı

1. Android `VpnService` (NetBare) yalnız `com.RGames.Romia2Mobil` bağlantısını yakalar.
2. Referans R2 Panel APK'sinden paket ayrıştırıcı ve varlık kataloğu uygulamanın kendi içine gömülür. R2 Panel uygulamasının kurulmasına veya HTTP API'sine ihtiyaç yoktur.
3. Oyun TCP akışından oyuncu konumu ve varlık VID/tip/vnum/x/y bilgisi çözülür.
4. Ayarlanan saldırı menzilindeki seçili türlerin tümü hedeflenir.
5. 7x açıkken R2 basit modundaki sıra tekrarlanır: her uygun hedef için `3D <VID:u32le>`, 10 ms bekleme, `02 00 <VID:u32le>`; tur sonunda 50 ms bekleme. Vuruş aralığı turların başlangıcını denetler. Kullanıcının isteğiyle hedef sayısı sınırı uygulanmaz. Kullanıcıdan elle vuruş beklenmez.

`app/src/main/assets/r2-parser.jar`, kullanıcının sağladığı R2 Panel APK'sinin `classes3.dex` dosyasını içerir. `entities_tr.txt`, `metins_tr.txt` ve `items_tr.txt` de aynı APK'den alınmıştır. Android yükleyicisi bu ayrıştırıcıyı uygulamanın özel önbelleğine kopyalar.

## Bilinen eksikler

- NetBare kaynakları Android SDK'nın Java derleyicisi ve `d8` aracıyla derlenip orijinal Metin İzleyici'nin kaydırmalı sürümüne `classes5.dex` olarak eklendi. Android Studio/Gradle gerekmedi.
- Test paketi `com.abdulkadir.metin.vpn` adıyla imzalandı; telefonunuzdaki Metin İzleyici'nin yanında kurulur. Aynı izleyici ekranını ve oyun overlay kodunu taşır, ayrıca ana ekranda VPN düğmesi bulunur. Orijinal uygulamanın kayıtlı ayarlarını otomatik devralmaz.
- Overlay içinde Kanallar bölümünde “7x vuruş”, “başlat” ve “durdur” kontrolleri bulunur. Bilgisayardaki panel verileri gelmese de “yerel VPN” satırı görünür. VPN ekranındaki “7x overlay panelini aç” düğmesi eski panel URL'si olmadan açar; Android ilk seferinde overlay ve VPN izinleri isteyebilir.
- NetBare kaynak deposunda MIT lisans dosyası bulunurken bazı Java dosyalarının başlığında GPLv3 metni vardır. Dağıtımdan önce kaynak dosyalarının lisansı doğrulanmalı.
- TCP yönlendirme, oyunun güncel IP/portu, paket ayrıştırma ve sürekli vuruşun sunucu etkisi telefonda ölçülmedi. `Attack7x.java` içindeki IP ve portlar sağlanan R2 Panel APK'sindeki referanstan alındı.

## Sonraki teknik adım

APK'yi rootsuz cihaza kurup önce VPN açıkken oyunun bağlandığını, ardından konum/varlık ayrıştırmasını ve vuruşun oyundaki etkisini logcat ile gözleyin. Sorun çıkarsa `Metin7x` veya `NetBare` etiketli loglar incelenmelidir. Orijinal Metin İzleyici uygulamasının imza anahtarı mevcut olmadığından test APK'si onun üzerine güncelleme olarak kurulmaz.
