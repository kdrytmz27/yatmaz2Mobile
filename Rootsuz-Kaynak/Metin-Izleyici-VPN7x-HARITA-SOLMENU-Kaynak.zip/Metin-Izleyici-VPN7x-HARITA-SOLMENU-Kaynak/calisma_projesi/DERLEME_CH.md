# CH düzeltmesinin APK paketi

CH kapanışı Java kaynakta `NioTunnel`, `TcpTunnel`, `TcpVATunnel` dosyalarında
uygulanmıştır. `compiled/classes5.dex` sadece değişen 5 sınıfı; `classes6.dex`
önceki v2.2 paketindeki orijinal `classes5.dex` sınıflarını içerir. Android
bir sınıf için önce `classes5.dex` içine bakar; değişmeyen sınıflar
`classes6.dex` içinden yüklenir. Orijinal APK'de `classes.dex` ile
`classes4.dex` ve tüm kaynaklar korunur.

Derleme araçları: Android SDK platform-35 ve build-tools-35.0.0, JDK 17;
Guava ve BouncyCastle jar bağımlılıkları. Değişen Java sınıfları D8 ile
`--min-api 24` seçilerek dex'e çevrildi, APK hizalanıp v2/v3 ile imzalandı.
Telefon üzerinde kurulum veya oyunda CH değiştirme testi yapılmadı.

APK paket adı `com.abdulkadir.metin.vpn`, manifest sürüm kodu 12. Önceki
imzadan farklı bir imza kullanıldı. Kurulurken imza uyuşmazlığı görülürse
önce eski Metin İzleyici VPN uygulamasını kaldırın. Eski uygulamanın yerel
ayarları/verileri kaldırmayla silinebilir; gerekiyorsa önce cihazda yedekleyin.
Yeni imza anahtarını ve şifresini sonraki güncellemeler için ayrı tutun.
