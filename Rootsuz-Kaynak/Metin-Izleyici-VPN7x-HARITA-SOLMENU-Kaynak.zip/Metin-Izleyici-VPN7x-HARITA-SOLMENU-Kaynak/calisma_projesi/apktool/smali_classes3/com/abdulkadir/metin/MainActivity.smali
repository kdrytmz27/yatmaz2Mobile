.class public final Lcom/abdulkadir/metin/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# instance fields
.field private boyut:I

.field private final boyutBtn:[Landroid/widget/Button;

.field private dikeyKutu:Landroid/widget/CheckBox;

.field private pref:Landroid/content/SharedPreferences;

.field private tekAdaKutu:Landroid/widget/CheckBox;

.field private tekSatirKutu:Landroid/widget/CheckBox;

.field private urlAlan:Landroid/widget/EditText;


# direct methods
.method public static synthetic $r8$lambda$SpR3LK_-mHVlHebSn8pyFMBrqv8(Lcom/abdulkadir/metin/MainActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/abdulkadir/metin/MainActivity;->lambda$onCreate$0(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$YJYx1yZajJijDteEXqIiW7bi2HY(Lcom/abdulkadir/metin/MainActivity;ILandroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1, p2}, Lcom/abdulkadir/metin/MainActivity;->lambda$boyutSecici$2(ILandroid/view/View;)V

    return-void
.end method

.method public static synthetic $r8$lambda$j1lpj0nMOfQ784PJmMhlKcnI-vo(Lcom/abdulkadir/metin/MainActivity;Landroid/view/View;)V
    .locals 0

    invoke-direct {p0, p1}, Lcom/abdulkadir/metin/MainActivity;->lambda$onCreate$1(Landroid/view/View;)V

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 28
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    .line 33
    const/4 v0, 0x3

    new-array v0, v0, [Landroid/widget/Button;

    iput-object v0, p0, Lcom/abdulkadir/metin/MainActivity;->boyutBtn:[Landroid/widget/Button;

    return-void
.end method

.method private aralikli(I)Landroid/widget/LinearLayout$LayoutParams;
    .locals 3
    .param p1, "ust"    # I

    .line 225
    new-instance v0, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v1, -0x1

    const/4 v2, -0x2

    invoke-direct {v0, v1, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 228
    .local v0, "lp":Landroid/widget/LinearLayout$LayoutParams;
    iput p1, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    .line 229
    return-object v0
.end method

.method private baslat()V
    .locals 14

    .line 101
    const-string v0, "k"

    iget-object v1, p0, Lcom/abdulkadir/metin/MainActivity;->urlAlan:Landroid/widget/EditText;

    invoke-virtual {v1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    .line 102
    .local v1, "tam":Ljava/lang/String;
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_0

    const-string v0, "Adresi gir (panelden kopyala)"

    invoke-direct {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->toast(Ljava/lang/String;)V

    return-void

    .line 103
    :cond_0
    const-string v2, "http"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "https://"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 107
    :cond_1
    move-object v2, v1

    .local v2, "url":Ljava/lang/String;
    const-string v3, ""

    .line 109
    .local v3, "kk":Ljava/lang/String;
    :try_start_0
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    .line 110
    .local v4, "u":Landroid/net/Uri;
    invoke-virtual {v4, v0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    .line 111
    .local v5, "q":Ljava/lang/String;
    if-eqz v5, :cond_2

    move-object v3, v5

    .line 112
    :cond_2
    invoke-virtual {v4}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_3

    invoke-virtual {v4}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v6

    goto :goto_0

    :cond_3
    const-string v6, "https"

    .line 113
    .local v6, "scheme":Ljava/lang/String;
    :goto_0
    invoke-virtual {v4}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v7

    .line 114
    .local v7, "host":Ljava/lang/String;
    invoke-virtual {v4}, Landroid/net/Uri;->getPort()I

    move-result v8

    .line 115
    .local v8, "port":I
    if-eqz v7, :cond_5

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const-string v10, "://"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    if-lez v8, :cond_4

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v11, ":"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    goto :goto_1

    :cond_4
    const-string v10, ""

    :goto_1
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    move-object v2, v9

    goto :goto_2

    .line 116
    .end local v4    # "u":Landroid/net/Uri;
    .end local v5    # "q":Ljava/lang/String;
    .end local v6    # "scheme":Ljava/lang/String;
    .end local v7    # "host":Ljava/lang/String;
    .end local v8    # "port":I
    :catchall_0
    move-exception v4

    :cond_5
    :goto_2
    nop

    .line 118
    iget-object v4, p0, Lcom/abdulkadir/metin/MainActivity;->tekSatirKutu:Landroid/widget/CheckBox;

    invoke-virtual {v4}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v4

    .line 119
    .local v4, "tekSatir":Z
    iget-object v5, p0, Lcom/abdulkadir/metin/MainActivity;->tekAdaKutu:Landroid/widget/CheckBox;

    invoke-virtual {v5}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v5

    .line 120
    .local v5, "tekAda":Z
    iget-object v6, p0, Lcom/abdulkadir/metin/MainActivity;->dikeyKutu:Landroid/widget/CheckBox;

    invoke-virtual {v6}, Landroid/widget/CheckBox;->isChecked()Z

    move-result v6

    .line 121
    .local v6, "dikey":Z
    iget-object v7, p0, Lcom/abdulkadir/metin/MainActivity;->pref:Landroid/content/SharedPreferences;

    invoke-interface {v7}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "tamurl"

    invoke-interface {v7, v8, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v8, "url"

    invoke-interface {v7, v8, v2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7, v0, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    iget v9, p0, Lcom/abdulkadir/metin/MainActivity;->boyut:I

    .line 122
    const-string v10, "boyut"

    invoke-interface {v7, v10, v9}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v9, "tekSatir"

    invoke-interface {v7, v9, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    .line 123
    const-string v11, "tekAda"

    invoke-interface {v7, v11, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const-string v12, "dikey"

    invoke-interface {v7, v12, v6}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 125
    invoke-static {p0}, Landroid/provider/Settings;->canDrawOverlays(Landroid/content/Context;)Z

    move-result v7

    if-nez v7, :cond_6

    .line 126
    const-string v0, "Overlay iznini a\u00e7, sonra tekrar BA\u015eLAT"

    invoke-direct {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->toast(Ljava/lang/String;)V

    .line 128
    :try_start_1
    new-instance v0, Landroid/content/Intent;

    const-string v7, "android.settings.action.MANAGE_OVERLAY_PERMISSION"

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "package:"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    .line 130
    invoke-virtual {p0}, Lcom/abdulkadir/metin/MainActivity;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v8

    invoke-direct {v0, v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 128
    invoke-virtual {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_3

    .line 131
    :catchall_1
    move-exception v0

    :goto_3
    nop

    .line 132
    return-void

    .line 135
    :cond_6
    new-instance v7, Landroid/content/Intent;

    const-class v13, Lcom/abdulkadir/metin/OverlayServisi;

    invoke-direct {v7, p0, v13}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 136
    .local v7, "i":Landroid/content/Intent;
    invoke-virtual {v7, v8, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 137
    invoke-virtual {v7, v0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 138
    iget v0, p0, Lcom/abdulkadir/metin/MainActivity;->boyut:I

    invoke-virtual {v7, v10, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 139
    invoke-virtual {v7, v9, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 140
    invoke-virtual {v7, v11, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 141
    invoke-virtual {v7, v12, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 142
    invoke-virtual {p0, v7}, Lcom/abdulkadir/metin/MainActivity;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 144
    const-string v0, "ba\u015flad\u0131 \u2014 oyuna ge\u00e7"

    invoke-direct {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->toast(Ljava/lang/String;)V

    .line 145
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->moveTaskToBack(Z)Z

    .line 146
    return-void
.end method

.method private boyutIsaretle()V
    .locals 4

    .line 207
    const/4 v0, 0x0

    .local v0, "i":I
    :goto_0
    const/4 v1, 0x3

    if-ge v0, v1, :cond_3

    .line 208
    iget v1, p0, Lcom/abdulkadir/metin/MainActivity;->boyut:I

    if-ne v0, v1, :cond_0

    const/4 v1, 0x1

    goto :goto_1

    :cond_0
    const/4 v1, 0x0

    .line 209
    .local v1, "sec":Z
    :goto_1
    iget-object v2, p0, Lcom/abdulkadir/metin/MainActivity;->boyutBtn:[Landroid/widget/Button;

    aget-object v2, v2, v0

    if-eqz v1, :cond_1

    const v3, -0xc82986

    goto :goto_2

    :cond_1
    const v3, -0xe5e0d5

    :goto_2
    invoke-virtual {v2, v3}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 210
    iget-object v2, p0, Lcom/abdulkadir/metin/MainActivity;->boyutBtn:[Landroid/widget/Button;

    aget-object v2, v2, v0

    if-eqz v1, :cond_2

    const v3, -0xf5f2ec

    goto :goto_3

    :cond_2
    const v3, -0x363122

    :goto_3
    invoke-virtual {v2, v3}, Landroid/widget/Button;->setTextColor(I)V

    .line 207
    .end local v1    # "sec":Z
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 212
    .end local v0    # "i":I
    :cond_3
    return-void
.end method

.method private boyutSecici()Landroid/view/View;
    .locals 11

    .line 185
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 186
    .local v0, "satir":Landroid/widget/LinearLayout;
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 187
    iget-object v2, p0, Lcom/abdulkadir/metin/MainActivity;->pref:Landroid/content/SharedPreferences;

    const-string v3, "boyut"

    const/4 v4, 0x1

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    iput v2, p0, Lcom/abdulkadir/metin/MainActivity;->boyut:I

    .line 188
    const/4 v2, 0x3

    new-array v3, v2, [Ljava/lang/String;

    const-string v5, "K\u00fc\u00e7\u00fck"

    aput-object v5, v3, v1

    const-string v5, "Orta"

    aput-object v5, v3, v4

    const-string v4, "B\u00fcy\u00fck"

    const/4 v5, 0x2

    aput-object v4, v3, v5

    .line 189
    .local v3, "adlar":[Ljava/lang/String;
    const/4 v4, 0x0

    .local v4, "i":I
    :goto_0
    if-ge v4, v2, :cond_1

    .line 190
    move v6, v4

    .line 191
    .local v6, "idx":I
    new-instance v7, Landroid/widget/Button;

    invoke-direct {v7, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 192
    .local v7, "b":Landroid/widget/Button;
    aget-object v8, v3, v4

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 193
    invoke-virtual {v7, v1}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 194
    const/high16 v8, 0x41500000    # 13.0f

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setTextSize(F)V

    .line 195
    new-instance v8, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda2;

    invoke-direct {v8, p0, v6}, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda2;-><init>(Lcom/abdulkadir/metin/MainActivity;I)V

    invoke-virtual {v7, v8}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 196
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->boyutBtn:[Landroid/widget/Button;

    aput-object v7, v8, v4

    .line 197
    new-instance v8, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, -0x2

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-direct {v8, v1, v9, v10}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 199
    .local v8, "lp":Landroid/widget/LinearLayout$LayoutParams;
    if-ge v4, v5, :cond_0

    const/4 v9, 0x6

    invoke-direct {p0, v9}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v9

    goto :goto_1

    :cond_0
    move v9, v1

    :goto_1
    invoke-virtual {v8, v1, v1, v9, v1}, Landroid/widget/LinearLayout$LayoutParams;->setMargins(IIII)V

    .line 200
    invoke-virtual {v0, v7, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 189
    .end local v6    # "idx":I
    .end local v7    # "b":Landroid/widget/Button;
    .end local v8    # "lp":Landroid/widget/LinearLayout$LayoutParams;
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 202
    .end local v4    # "i":I
    :cond_1
    invoke-direct {p0}, Lcom/abdulkadir/metin/MainActivity;->boyutIsaretle()V

    .line 203
    return-object v0
.end method

.method private dp(I)I
    .locals 2
    .param p1, "v"    # I

    .line 237
    int-to-float v0, p1

    invoke-virtual {p0}, Lcom/abdulkadir/metin/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    return v0
.end method

.method private dugme(Ljava/lang/String;II)Landroid/widget/Button;
    .locals 2
    .param p1, "s"    # Ljava/lang/String;
    .param p2, "arka"    # I
    .param p3, "yazi"    # I

    .line 175
    new-instance v0, Landroid/widget/Button;

    invoke-direct {v0, p0}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    .line 176
    .local v0, "b":Landroid/widget/Button;
    invoke-virtual {v0, p1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 177
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setAllCaps(Z)V

    .line 178
    invoke-virtual {v0, p3}, Landroid/widget/Button;->setTextColor(I)V

    .line 179
    invoke-virtual {v0, p2}, Landroid/widget/Button;->setBackgroundColor(I)V

    .line 180
    const/high16 v1, 0x41800000    # 16.0f

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setTextSize(F)V

    .line 181
    return-object v0
.end method

.method private etiket(Ljava/lang/String;)Landroid/widget/TextView;
    .locals 4
    .param p1, "s"    # Ljava/lang/String;

    .line 150
    new-instance v0, Landroid/widget/TextView;

    invoke-direct {v0, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 151
    .local v0, "t":Landroid/widget/TextView;
    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 152
    const v1, -0x948f80

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 153
    const/high16 v1, 0x41400000    # 12.0f

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setTextSize(F)V

    .line 154
    const/16 v1, 0xc

    invoke-direct {p0, v1}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v1

    const/4 v2, 0x4

    invoke-direct {p0, v2}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v0, v3, v1, v3, v2}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 155
    return-object v0
.end method

.method private giris(Ljava/lang/String;Z)Landroid/widget/EditText;
    .locals 3
    .param p1, "deger"    # Ljava/lang/String;
    .param p2, "parola"    # Z

    .line 159
    new-instance v0, Landroid/widget/EditText;

    invoke-direct {v0, p0}, Landroid/widget/EditText;-><init>(Landroid/content/Context;)V

    .line 160
    .local v0, "e":Landroid/widget/EditText;
    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 161
    const v1, -0x363122

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setTextColor(I)V

    .line 162
    const v1, -0xc0baaa

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setHintTextColor(I)V

    .line 163
    const/high16 v1, 0x41700000    # 15.0f

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setTextSize(F)V

    .line 164
    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSingleLine(Z)V

    .line 165
    nop

    .line 167
    if-eqz p2, :cond_0

    const/16 v1, 0x80

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    const v2, 0x80001

    or-int/2addr v1, v2

    .line 165
    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setInputType(I)V

    .line 168
    const v1, -0xede9e1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setBackgroundColor(I)V

    .line 169
    const/16 v1, 0xa

    invoke-direct {p0, v1}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v1

    .line 170
    .local v1, "p":I
    invoke-virtual {v0, v1, v1, v1, v1}, Landroid/widget/EditText;->setPadding(IIII)V

    .line 171
    return-object v0
.end method

.method private kutu(Ljava/lang/String;Z)Landroid/widget/CheckBox;
    .locals 4
    .param p1, "s"    # Ljava/lang/String;
    .param p2, "sec"    # Z

    .line 215
    new-instance v0, Landroid/widget/CheckBox;

    invoke-direct {v0, p0}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 216
    .local v0, "c":Landroid/widget/CheckBox;
    invoke-virtual {v0, p1}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 217
    const v1, -0x363122

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setTextColor(I)V

    .line 218
    const/high16 v1, 0x41600000    # 14.0f

    invoke-virtual {v0, v1}, Landroid/widget/CheckBox;->setTextSize(F)V

    .line 219
    invoke-virtual {v0, p2}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 220
    const/4 v1, 0x4

    invoke-direct {p0, v1}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v1

    const/16 v2, 0x8

    invoke-direct {p0, v2}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3, v3}, Landroid/widget/CheckBox;->setPadding(IIII)V

    .line 221
    return-object v0
.end method

.method private synthetic lambda$boyutSecici$2(ILandroid/view/View;)V
    .locals 0
    .param p1, "idx"    # I
    .param p2, "v"    # Landroid/view/View;

    .line 195
    iput p1, p0, Lcom/abdulkadir/metin/MainActivity;->boyut:I

    invoke-direct {p0}, Lcom/abdulkadir/metin/MainActivity;->boyutIsaretle()V

    return-void
.end method

.method private synthetic lambda$onCreate$0(Landroid/view/View;)V
    .locals 0
    .param p1, "v"    # Landroid/view/View;

    .line 78
    invoke-direct {p0}, Lcom/abdulkadir/metin/MainActivity;->baslat()V

    return-void
.end method

.method private synthetic lambda$onCreate$1(Landroid/view/View;)V
    .locals 2
    .param p1, "v"    # Landroid/view/View;

    .line 83
    new-instance v0, Landroid/content/Intent;

    const-class v1, Lcom/abdulkadir/metin/OverlayServisi;

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->stopService(Landroid/content/Intent;)Z

    .line 84
    const-string v0, "\u00e7ubuk kapat\u0131ld\u0131"

    invoke-direct {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->toast(Ljava/lang/String;)V

    .line 85
    return-void
.end method

.method private toast(Ljava/lang/String;)V
    .locals 1
    .param p1, "s"    # Ljava/lang/String;

    .line 233
    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 234
    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 11
    .param p1, "b"    # Landroid/os/Bundle;

    .line 39
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 40
    const-string v0, "metin"

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/abdulkadir/metin/MainActivity;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/abdulkadir/metin/MainActivity;->pref:Landroid/content/SharedPreferences;

    .line 42
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    .line 43
    .local v0, "kok":Landroid/widget/LinearLayout;
    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 44
    const/16 v2, 0x16

    invoke-direct {p0, v2}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v3

    .line 45
    .local v3, "p":I
    invoke-virtual {v0, v3, v3, v3, v3}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 46
    const v4, -0xf5f2ec

    invoke-virtual {v0, v4}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 48
    new-instance v5, Landroid/widget/TextView;

    invoke-direct {v5, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 49
    .local v5, "baslik":Landroid/widget/TextView;
    const-string v6, "Metin \u0130zleyici"

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 50
    const v6, -0x363122

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 51
    const/high16 v7, 0x41b00000    # 22.0f

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setTextSize(F)V

    .line 52
    const/4 v7, 0x4

    invoke-direct {p0, v7}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v7

    invoke-virtual {v5, v1, v1, v1, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 53
    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 55
    new-instance v7, Landroid/widget/TextView;

    invoke-direct {v7, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 56
    .local v7, "alt":Landroid/widget/TextView;
    const-string v8, "Oyunun \u00fcst\u00fcnde k\u00fc\u00e7\u00fck renkli ch \u00e7ubu\u011fu."

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 57
    const v8, -0x948f80

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 58
    const/high16 v8, 0x41400000    # 12.0f

    invoke-virtual {v7, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 59
    const/16 v8, 0x12

    invoke-direct {p0, v8}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v8

    invoke-virtual {v7, v1, v1, v1, v8}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 60
    invoke-virtual {v0, v7}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    invoke-static {p0, v0}, Lcom/abdulkadir/metin7x/VpnActivity;->addLauncher(Landroid/content/Context;Landroid/widget/LinearLayout;)V

    .line 62
    const-string v8, "Tam adres (panelden kopyala \u2014 parola i\u00e7inde)"

    invoke-direct {p0, v8}, Lcom/abdulkadir/metin/MainActivity;->etiket(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 63
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->pref:Landroid/content/SharedPreferences;

    const-string v9, "tamurl"

    const-string v10, ""

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-direct {p0, v8, v1}, Lcom/abdulkadir/metin/MainActivity;->giris(Ljava/lang/String;Z)Landroid/widget/EditText;

    move-result-object v8

    iput-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->urlAlan:Landroid/widget/EditText;

    .line 64
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->urlAlan:Landroid/widget/EditText;

    const-string v9, "https://xxxx.trycloudflare.com/?k=parola"

    invoke-virtual {v8, v9}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

    .line 65
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->urlAlan:Landroid/widget/EditText;

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 67
    const-string v8, "H\u00fccre boyutu"

    invoke-direct {p0, v8}, Lcom/abdulkadir/metin/MainActivity;->etiket(Ljava/lang/String;)Landroid/widget/TextView;

    move-result-object v8

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 68
    invoke-direct {p0}, Lcom/abdulkadir/metin/MainActivity;->boyutSecici()Landroid/view/View;

    move-result-object v8

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 70
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->pref:Landroid/content/SharedPreferences;

    const-string v9, "dikey"

    invoke-interface {v8, v9, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const-string v9, "Dikey \u00e7ubuk (ch\'ler alt alta)"

    invoke-direct {p0, v9, v8}, Lcom/abdulkadir/metin/MainActivity;->kutu(Ljava/lang/String;Z)Landroid/widget/CheckBox;

    move-result-object v8

    iput-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->dikeyKutu:Landroid/widget/CheckBox;

    .line 71
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->dikeyKutu:Landroid/widget/CheckBox;

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 72
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->pref:Landroid/content/SharedPreferences;

    const-string v9, "tekSatir"

    invoke-interface {v8, v9, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const-string v9, "Tek \u00e7izgi (adalar\u0131 birle\u015ftir)"

    invoke-direct {p0, v9, v8}, Lcom/abdulkadir/metin/MainActivity;->kutu(Ljava/lang/String;Z)Landroid/widget/CheckBox;

    move-result-object v8

    iput-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->tekSatirKutu:Landroid/widget/CheckBox;

    .line 73
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->tekSatirKutu:Landroid/widget/CheckBox;

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 74
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->pref:Landroid/content/SharedPreferences;

    const-string v9, "tekAda"

    invoke-interface {v8, v9, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const-string v9, "Sadece 1. ada"

    invoke-direct {p0, v9, v8}, Lcom/abdulkadir/metin/MainActivity;->kutu(Ljava/lang/String;Z)Landroid/widget/CheckBox;

    move-result-object v8

    iput-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->tekAdaKutu:Landroid/widget/CheckBox;

    .line 75
    iget-object v8, p0, Lcom/abdulkadir/metin/MainActivity;->tekAdaKutu:Landroid/widget/CheckBox;

    invoke-virtual {v0, v8}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 77
    const-string v8, "BA\u015eLAT"

    const v9, -0xc82986

    invoke-direct {p0, v8, v9, v4}, Lcom/abdulkadir/metin/MainActivity;->dugme(Ljava/lang/String;II)Landroid/widget/Button;

    move-result-object v4

    .line 78
    .local v4, "basla":Landroid/widget/Button;
    new-instance v8, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda0;

    invoke-direct {v8, p0}, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda0;-><init>(Lcom/abdulkadir/metin/MainActivity;)V

    invoke-virtual {v4, v8}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 79
    invoke-direct {p0, v2}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v2

    invoke-direct {p0, v2}, Lcom/abdulkadir/metin/MainActivity;->aralikli(I)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v2

    invoke-virtual {v0, v4, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 81
    const-string v2, "DURDUR"

    const v8, -0xe5e0d5

    invoke-direct {p0, v2, v8, v6}, Lcom/abdulkadir/metin/MainActivity;->dugme(Ljava/lang/String;II)Landroid/widget/Button;

    move-result-object v2

    .line 82
    .local v2, "durdur":Landroid/widget/Button;
    new-instance v6, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda1;

    invoke-direct {v6, p0}, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda1;-><init>(Lcom/abdulkadir/metin/MainActivity;)V

    invoke-virtual {v2, v6}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 86
    const/16 v6, 0xa

    invoke-direct {p0, v6}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v6

    invoke-direct {p0, v6}, Lcom/abdulkadir/metin/MainActivity;->aralikli(I)Landroid/widget/LinearLayout$LayoutParams;

    move-result-object v6

    invoke-virtual {v0, v2, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 88
    new-instance v6, Landroid/widget/TextView;

    invoke-direct {v6, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 89
    .local v6, "ipucu":Landroid/widget/TextView;
    const-string v8, "Ba\u015flatt\u0131ktan sonra oyuna ge\u00e7. \u00c7ubu\u011fu parmakla s\u00fcr\u00fckleyip istedi\u011fin yere koyabilirsin. Ye\u015fil = metin var, turuncu = metin kesiliyor."

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 92
    const v8, -0xa59f8e

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextColor(I)V

    .line 93
    const/high16 v8, 0x41300000    # 11.0f

    invoke-virtual {v6, v8}, Landroid/widget/TextView;->setTextSize(F)V

    .line 94
    const/16 v8, 0x14

    invoke-direct {p0, v8}, Lcom/abdulkadir/metin/MainActivity;->dp(I)I

    move-result v8

    invoke-virtual {v6, v1, v8, v1, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 95
    invoke-virtual {v0, v6}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 97
    invoke-virtual {p0, v0}, Lcom/abdulkadir/metin/MainActivity;->setContentView(Landroid/view/View;)V

    .line 98
    return-void
.end method
