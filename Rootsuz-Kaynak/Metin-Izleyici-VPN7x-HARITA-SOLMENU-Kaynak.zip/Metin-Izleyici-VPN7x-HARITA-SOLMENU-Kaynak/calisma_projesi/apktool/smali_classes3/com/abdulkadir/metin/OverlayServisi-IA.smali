.class public final synthetic Lcom/abdulkadir/metin/OverlayServisi-IA;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"
