.class public final synthetic Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/abdulkadir/metin/MainActivity;"
    method = "lambda$onCreate$1"
    proto = "(Landroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "9aaf5f34c4c84da429ef7f8f6217a1817876f2618cfcf539aba3d7d5a0c703e0"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/abdulkadir/metin/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/abdulkadir/metin/MainActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda1;->f$0:Lcom/abdulkadir/metin/MainActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/abdulkadir/metin/MainActivity$$ExternalSyntheticLambda1;->f$0:Lcom/abdulkadir/metin/MainActivity;

    invoke-static {v0, p1}, Lcom/abdulkadir/metin/MainActivity;->$r8$lambda$j1lpj0nMOfQ784PJmMhlKcnI-vo(Lcom/abdulkadir/metin/MainActivity;Landroid/view/View;)V

    return-void
.end method
