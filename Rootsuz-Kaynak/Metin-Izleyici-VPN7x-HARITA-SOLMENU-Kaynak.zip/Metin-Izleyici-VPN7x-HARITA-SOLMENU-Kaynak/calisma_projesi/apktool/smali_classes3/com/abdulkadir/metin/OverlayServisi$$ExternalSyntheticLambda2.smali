.class public final synthetic Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/abdulkadir/metin/OverlayServisi;"
    method = "lambda$detayCiz$9"
    proto = "(ILandroid/view/View;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "9aaf5f34c4c84da429ef7f8f6217a1817876f2618cfcf539aba3d7d5a0c703e0"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/abdulkadir/metin/OverlayServisi;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Lcom/abdulkadir/metin/OverlayServisi;I)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda2;->f$0:Lcom/abdulkadir/metin/OverlayServisi;

    iput p2, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda2;->f$1:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda2;->f$0:Lcom/abdulkadir/metin/OverlayServisi;

    iget v1, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda2;->f$1:I

    invoke-static {v0, v1, p1}, Lcom/abdulkadir/metin/OverlayServisi;->$r8$lambda$u5AqHE2LXOa9kLkDBJZrK1xMF4I(Lcom/abdulkadir/metin/OverlayServisi;ILandroid/view/View;)V

    return-void
.end method
