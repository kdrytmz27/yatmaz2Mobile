.class public final synthetic Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation runtime Lcom/android/tools/r8/annotations/LambdaMethod;
    holder = "Lcom/abdulkadir/metin/OverlayServisi;"
    method = "lambda$komut$2"
    proto = "(Lorg/json/JSONObject;)V"
.end annotation

.annotation build Lcom/android/tools/r8/annotations/SynthesizedClassV2;
    apiLevel = -0x2
    kind = 0x13
    versionHash = "9aaf5f34c4c84da429ef7f8f6217a1817876f2618cfcf539aba3d7d5a0c703e0"
.end annotation


# instance fields
.field public final synthetic f$0:Lcom/abdulkadir/metin/OverlayServisi;

.field public final synthetic f$1:Lorg/json/JSONObject;


# direct methods
.method public synthetic constructor <init>(Lcom/abdulkadir/metin/OverlayServisi;Lorg/json/JSONObject;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda8;->f$0:Lcom/abdulkadir/metin/OverlayServisi;

    iput-object p2, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda8;->f$1:Lorg/json/JSONObject;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda8;->f$0:Lcom/abdulkadir/metin/OverlayServisi;

    iget-object v1, p0, Lcom/abdulkadir/metin/OverlayServisi$$ExternalSyntheticLambda8;->f$1:Lorg/json/JSONObject;

    invoke-static {v0, v1}, Lcom/abdulkadir/metin/OverlayServisi;->$r8$lambda$D3AZUIrs3krlYiTEChNSM5SKcDg(Lcom/abdulkadir/metin/OverlayServisi;Lorg/json/JSONObject;)V

    return-void
.end method
