# Metin İzleyici VPN 7x: APK'den oluşturulmuş çalışma kopyası

## CH geçişi düzeltmesi (25 Eylül 2026)

`java_source/netbare-core` içindeki TCP aktarımı güncellendi. Sunucu veya oyun
bağlantısı EOF ile kapanınca ilgili yönde okumalar durdurulur, karşı uçtaki
bekleyen paketler gönderildikten sonra TCP FIN iletilir. İki yön bitip kuyruklar
boşalınca yalnız o TCP tüneli kapatılır; VPN hizmeti çalışmaya devam eder.
`TcpVATunnel` yönlere ait bitiş bildirimlerini de doğru eşleştirir. Seçicinin
okuma ve yazma ilgisi, yazma kuyruğu doluyken dahi gelen paketleri okumayı
sürdürür. `tests/tcp_close/run.sh` yerel TCP üstünde son veri, FIN, yarım kapama
ve ardışık iki bağlantıyı sınar (`sh tests/tcp_close/run.sh`).

**Bu paket CH düzeltmesinin kaynak kodunu ve imzalı APK'sini içerir.**
`compiled/classes5.dex` yeni TCP sınıflarını, `compiled/classes6.dex` önceki
paketin geri kalan sınıflarını taşır. Android bu sınıfları DEX sırasına göre
yüklüyor. `Metin-Izleyici-VPN-7x-Telefon.apk` yeni paketle değiştirilmiştir.
Yeni sürümün imzası önceki APK'nin imzasından farklıdır. Aynı paket adıyla
eskinin üzerine kurulamaz: önce mevcut `com.abdulkadir.metin.vpn` uygulamasını
kaldırmak gerekir; bu işlem o uygulamanın yerel verilerini siler. Yeni APK'nin
v2/v3 imzası, DEX içeriği ve hizası doğrulandı. Gerçek telefonda ve oyunda CH
geçişi henüz doğrulanmadı. Aşağıdaki ilk derleme kaydı önceki APK'ye aittir.

Android Studio projesi gerekmiyor. `apktool/`, kullanıcının verdiği Metin İzleyici APK'sinin önceki kaydırmalı sürümünden çözümlenmiş ve VPN ekranı eklenmiş halidir. `java_source/` VPN, otomatik hedefleme ve NetBare kaynaklarını; `compiled/classes5.dex` Android için derlenen bu kodu taşır. Klasörün kökündeki APK imzalı deneme paketidir.

APK'nin Android paket adı `com.abdulkadir.metin.vpn` olduğu için kurulu Metin İzleyici uygulamasını silmeden yanında kurulabilir. İzleyici ekranı ve overlay kodu korunmuştur; ana ekrana “ROOTSUZ VPN / OTOMATİK 7x” düğmesi eklendi.

Overlay önce küçük görünümde açılır; dişliye basmadan görünen 48 dp genişlikteki “7x” başlığına dokunarak küçük kontrol bölümünü açıp kapatabilirsiniz. Açıkken küçük ▶ başlat / ■ durdur ile “Topla Açık/Kapalı” düğmesi görünür; bu bölüm eski ch görünümünü genişletmez. Dişli açıldığında asıl overlay penceresi ekrana sığan genişliğe çıkar ve eski ch ızgarası geçici olarak gizlenir; ayarlar, buff ve ch satırları kaydırılabilir geniş ekranda görünür. Üstteki “Küçült” düğmesi eski küçük ch görünümünü ve ölçüsünü geri getirir. Açık pencerenin yüksekliği ekrandaki kullanılabilir alana göre ayarlanır. Panelin üstünde “Buff'çıyı çek” ve 1–8 ch düğmeleri görünür; bu bölüm izleyicinin panel bağlantısıyla çalışır. “Sadece ch izleme” düğmesi ayarları gizleyip buff ve kanalları gösterir; “Geniş ayarlar” ile geri dönülür. Geniş panel kaydırılabilir: canavar/metin seçimi, saldırı menzili ve vuruş aralığı, isteğe bağlı PvP, otomatik yerden toplama, Yang önceliği, sahip ve eşya filtreleri içerir. “Yerdekileri listele” ayrıştırılmış ve filtrelenmiş yakın eşyaları gösterir. Değişiklikler cihazda saklanır ve sonraki vuruş/toplama döngüsünde uygulanır. Ch hesabı satırları izleyicinin kendi panel verisi geldiğinde görünür.

Overlay penceresi boş alana uzun basıp çekerek veya boş alanda yatay çekerek taşınabilir. İçerikte dikey kaydırma korunur; içerik en üst/alt sınırdayken dışarı doğru çekmek pencereyi taşır. Eski üst kenar sürüklemesi de çalışır; konum ekranın görünür alanıyla sınırlanır.

`Attack7x` manuel vuruş beklemez. VPN oyun bağlantısından gelen veriyi R2 Panel'den alınmış paket ayrıştırıcısıyla çözer. Sürüm 2.1, sağlanan R2 basit mod işçisinin paket ve bekleme sırasını kullanır: her hedef için `3D <VID>` gönder, 10 ms bekle, `02 00 <VID>` gönder; turun sonunda 50 ms bekle. Vuruş aralığı, R2'deki gibi turların başlama aralığını kontrol eder; hedef başına 10 ms ve tur sonundaki 50 ms buna dahildir, bunlardan daha kısa aralık garanti edilmez. Kullanıcının tüm menzil hedefleri isteği korunur: R2'nin `max_hedef` sınırı uygulanmaz; seçili türdeki tüm uygun hedefler döngüye girer. Başlat açık olduğu sürece turlar tekrarlanır; elle saldırı, durdurma koşulu değildir. Toplama ayrı iş parçacığında çalışır. Telefon tarafındaki 7x ve toplama, R2 Panel uygulaması, PC sunucusu veya root gerektirmez. Uzak ch hesabı izleme ve bu hesapların başlat/durdur komutları için mevcut izleyicinin panel bağlantısı gereklidir.

Ada hücreleri ortak genişlik ve yükseklik kullanır. Buff simgesinin ilk ada sütununu büyütüp diğerini dar bırakması engellenir; mevcut küçük/orta/büyük hücre ayarı korunur.

## Derleme kaydı

- Android SDK 35, Build Tools 35, Java 17 `javac`, `d8` ve Apktool 2.12.1 kullanıldı.
- NetBare Java kodu ve modül kodu Android 35 `android.jar`, komut satırı araçları ile gelen Guava/BouncyCastle JAR'ları ve kaynak ağacındaki Support uyumluluk sınıflarıyla derlendi.
- `apktool b apktool` ile temel APK, ardından `compiled/classes5.dex` dosyası `classes5.dex` adıyla APK içine eklendi; `zipalign` ve `apksigner` ile paket hizalanıp imzalandı.
- APK imzası v2/v3 ile doğrulandı. **Telefona yükleme, overlay'in gerçek ekran boyutlarında görünümü, VPN bağlantısı, hedef algılama, toplama ve hasar etkisi henüz test edilmedi.**

NetBare deposundaki `LICENSE` MIT metni içerirken bazı kaynak dosyalarında GPLv3 üstbilgisi bulunuyor; her ikisi de `java_source/netbare-core` altında tutuldu.
