package com.github.megatronking.netbare;

public final class NetBareUtils {
    public static void closeQuietly(java.io.Closeable value) {
        try { if (value != null) value.close(); } catch (java.io.IOException ignored) { }
    }
}
