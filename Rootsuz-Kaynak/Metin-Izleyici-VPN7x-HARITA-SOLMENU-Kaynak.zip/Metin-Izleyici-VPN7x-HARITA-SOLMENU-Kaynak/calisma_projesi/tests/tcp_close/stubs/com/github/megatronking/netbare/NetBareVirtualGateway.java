package com.github.megatronking.netbare;
import com.github.megatronking.netbare.gateway.*;
import com.github.megatronking.netbare.net.Session;
import java.io.IOException;
import java.nio.ByteBuffer;
public final class NetBareVirtualGateway extends VirtualGateway {
    private final Request request;
    private final Response response;
    public NetBareVirtualGateway(Session session, Request request, Response response) {
        this.request = request;
        this.response = response;
    }
    @Override public void onRequest(ByteBuffer data) throws IOException { request.process(data); }
    @Override public void onResponse(ByteBuffer data) throws IOException { response.process(data); }
    @Override public void onRequestFinished() { }
    @Override public void onResponseFinished() { }
}
