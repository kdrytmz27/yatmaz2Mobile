package com.github.megatronking.netbare.gateway;
import com.github.megatronking.netbare.tunnel.NioTunnel;
import java.io.IOException;
import java.nio.ByteBuffer;
public final class Response {
    private final NioTunnel tunnel;
    public Response(NioTunnel tunnel) { this.tunnel = tunnel; }
    public void process(ByteBuffer bytes) throws IOException { tunnel.write(bytes); }
}
