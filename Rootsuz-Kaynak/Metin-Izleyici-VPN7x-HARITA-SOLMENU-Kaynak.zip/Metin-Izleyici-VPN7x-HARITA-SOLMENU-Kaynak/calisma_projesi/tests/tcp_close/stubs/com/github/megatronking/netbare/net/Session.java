package com.github.megatronking.netbare.net;
public final class Session { }
