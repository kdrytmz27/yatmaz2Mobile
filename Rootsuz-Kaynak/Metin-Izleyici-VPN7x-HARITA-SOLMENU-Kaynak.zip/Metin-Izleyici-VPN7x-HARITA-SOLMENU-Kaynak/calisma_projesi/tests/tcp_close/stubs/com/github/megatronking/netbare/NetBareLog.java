package com.github.megatronking.netbare;

public final class NetBareLog {
    public static void i(String message, Object... args) { }
}
