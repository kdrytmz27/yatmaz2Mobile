package com.github.megatronking.netbare.gateway;
import java.io.IOException;
import java.nio.ByteBuffer;
public abstract class VirtualGateway {
    public abstract void onRequest(ByteBuffer data) throws IOException;
    public abstract void onResponse(ByteBuffer data) throws IOException;
    public abstract void onRequestFinished();
    public abstract void onResponseFinished();
}
