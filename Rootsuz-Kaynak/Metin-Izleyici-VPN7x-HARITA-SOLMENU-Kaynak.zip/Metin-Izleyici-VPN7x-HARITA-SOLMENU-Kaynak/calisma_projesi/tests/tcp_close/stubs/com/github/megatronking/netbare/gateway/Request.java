package com.github.megatronking.netbare.gateway;
import com.github.megatronking.netbare.tunnel.NioTunnel;
import java.io.IOException;
import java.nio.ByteBuffer;
public final class Request {
    private final NioTunnel tunnel;
    public Request(NioTunnel tunnel) { this.tunnel = tunnel; }
    public void process(ByteBuffer bytes) throws IOException { tunnel.write(bytes); }
}
