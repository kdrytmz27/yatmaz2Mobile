#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
out_dir="$(mktemp -d)"
trap 'rm -rf "$out_dir"' EXIT
src=java_source/netbare-core/src/main/java/com/github/megatronking/netbare/tunnel
java com.sun.tools.javac.Main -d "$out_dir" \
  tests/tcp_close/stubs/com/github/megatronking/netbare/NetBareUtils.java \
  tests/tcp_close/stubs/com/github/megatronking/netbare/NetBareLog.java \
  tests/tcp_close/stubs/com/github/megatronking/netbare/NetBareVirtualGateway.java \
  tests/tcp_close/stubs/com/github/megatronking/netbare/net/Session.java \
  tests/tcp_close/stubs/com/github/megatronking/netbare/gateway/*.java \
  "$src/NioCallback.java" "$src/Tunnel.java" "$src/NioTunnel.java" "$src/TcpTunnel.java" \
  "$src/VirtualGatewayTunnel.java" "$src/ConnectionShutdownException.java" "$src/TcpVATunnel.java" \
  tests/tcp_close/src/com/github/megatronking/netbare/tunnel/TcpHalfCloseTest.java
java -cp "$out_dir" com.github.megatronking.netbare.tunnel.TcpHalfCloseTest
