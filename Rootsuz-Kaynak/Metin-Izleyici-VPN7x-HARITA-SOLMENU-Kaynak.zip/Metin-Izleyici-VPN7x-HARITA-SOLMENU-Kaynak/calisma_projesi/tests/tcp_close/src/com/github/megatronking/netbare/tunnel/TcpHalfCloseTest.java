package com.github.megatronking.netbare.tunnel;

import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.SelectionKey;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import com.github.megatronking.netbare.net.Session;

/** JVM loopback test for queued bytes, FIN propagation and independent reads. */
public final class TcpHalfCloseTest {
    private static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }

    public static void main(String[] args) throws Exception {
        try (Selector selector = Selector.open();
             ServerSocketChannel listener = ServerSocketChannel.open()) {
            listener.bind(new InetSocketAddress("127.0.0.1", 0));
            try (SocketChannel peer = SocketChannel.open(listener.getLocalAddress());
                 SocketChannel local = listener.accept()) {
                peer.socket().setSoTimeout(2000);
                TcpTunnel tunnel = new TcpTunnel(local, selector) {
                    @Override protected int channelWrite(ByteBuffer buffer) throws java.io.IOException {
                        int oldLimit = buffer.limit();
                        buffer.limit(Math.min(oldLimit, buffer.position() + 2));
                        try { return super.channelWrite(buffer); }
                        finally { buffer.limit(oldLimit); }
                    }
                };
                tunnel.prepareRead();
                tunnel.write(ByteBuffer.wrap("LAST".getBytes(StandardCharsets.US_ASCII)));
                tunnel.shutdownOutputAfterPendingWrites();
                check(!tunnel.isOutputShutdown(), "FIN preceded queued data");
                tunnel.onWrite();
                check(!tunnel.isOutputShutdown(), "FIN preceded partially written data");
                tunnel.onWrite();
                check(tunnel.isOutputShutdown(), "FIN not sent after queued data");
                byte[] received = new byte[4];
                int position = 0;
                while (position < received.length) {
                    int count = peer.socket().getInputStream().read(received, position, 4 - position);
                    check(count > 0, "lost queued data");
                    position += count;
                }
                check("LAST".equals(new String(received, StandardCharsets.US_ASCII)), "wrong queued data");
                check(peer.socket().getInputStream().read() == -1, "peer never received FIN");
                peer.write(ByteBuffer.wrap("OK".getBytes(StandardCharsets.US_ASCII)));
                ByteBuffer response = ByteBuffer.allocate(2);
                long until = System.currentTimeMillis() + 2000;
                while (response.position() < 2 && System.currentTimeMillis() < until) local.read(response);
                check("OK".equals(new String(response.array(), StandardCharsets.US_ASCII)),
                        "FIN prematurely closed reverse direction");
                tunnel.stopRead();
                check(local.isOpen(), "stopRead closed socket");
                tunnel.close();
            }
        }
        for (int ch = 1; ch <= 2; ch++) checkChannelTransition(ch);
        System.out.println("TCP half-close: PASS");
    }

    private static void pump(Selector selector) throws Exception {
        selector.select(100);
        Iterator<SelectionKey> keys = selector.selectedKeys().iterator();
        while (keys.hasNext()) {
            SelectionKey key = keys.next();
            keys.remove();
            if (!key.isValid()) continue;
            NioTunnel tunnel = (NioTunnel) key.attachment();
            if (key.isReadable()) tunnel.onRead();
            else if (key.isWritable()) tunnel.onWrite();
        }
    }

    private static void checkChannelTransition(int channel) throws Exception {
        try (Selector selector = Selector.open();
             ServerSocketChannel gameListener = ServerSocketChannel.open();
             ServerSocketChannel remoteListener = ServerSocketChannel.open()) {
            gameListener.bind(new InetSocketAddress("127.0.0.1", 0));
            remoteListener.bind(new InetSocketAddress("127.0.0.1", 0));
            try (SocketChannel game = SocketChannel.open(gameListener.getLocalAddress());
                 SocketChannel proxy = gameListener.accept();
                 SocketChannel server = SocketChannel.open(remoteListener.getLocalAddress());
                 SocketChannel remote = remoteListener.accept()) {
                game.socket().setSoTimeout(2000);
                server.socket().setSoTimeout(2000);
                TcpTunnel proxyTunnel = new TcpTunnel(proxy, selector) { };
                TcpTunnel remoteTunnel = new TcpTunnel(remote, selector) { };
                TcpVATunnel relay = new TcpVATunnel(new Session(), proxyTunnel, remoteTunnel, 2048);
                // Accepted channels are already connected; invoke the ready callback directly.
                remoteTunnel.onConnected();
                byte[] payload = ("CH" + channel).getBytes(StandardCharsets.US_ASCII);
                server.write(ByteBuffer.wrap(payload));
                server.shutdownOutput();
                long deadline = System.currentTimeMillis() + 2000;
                while (!proxyTunnel.isOutputShutdown() && System.currentTimeMillis() < deadline)
                    pump(selector);
                check(proxyTunnel.isOutputShutdown(), "remote EOF did not reach game on CH " + channel);
                byte[] arrived = new byte[payload.length];
                int offset = 0;
                while (offset < arrived.length) {
                    int n = game.socket().getInputStream().read(arrived, offset, arrived.length - offset);
                    check(n > 0, "lost final server bytes on CH " + channel);
                    offset += n;
                }
                check(java.util.Arrays.equals(payload, arrived), "corrupted final bytes");
                check(game.socket().getInputStream().read() == -1, "game missing FIN");
                game.shutdownOutput();
                while ((proxy.isOpen() || remote.isOpen()) && System.currentTimeMillis() < deadline)
                    pump(selector);
                check(!proxy.isOpen() && !remote.isOpen(), "old CH tunnels remained open");
                check(server.socket().getInputStream().read() == -1, "server missing reverse FIN");
                relay.close();
            }
        }
    }
}
