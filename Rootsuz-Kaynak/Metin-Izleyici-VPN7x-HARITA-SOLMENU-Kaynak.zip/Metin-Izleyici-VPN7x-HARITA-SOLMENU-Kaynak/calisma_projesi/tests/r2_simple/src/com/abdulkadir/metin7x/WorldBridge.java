package com.abdulkadir.metin7x;
import java.util.*;
class WorldBridge {
 static class Target { final int vid; final boolean player=false; Target(int id){vid=id;} }
 static class GroundItem { int vid; }
 static final WorldBridge INSTANCE=new WorldBridge(); long revision=1;
 static WorldBridge get(){return INSTANCE;} Object newParser(){return new Object();}
 void feedOutgoing(Object p,byte[] b){} void feedIncoming(Object p,byte[] b){revision++;}
 long lastUpdate(){return revision;} boolean hasPosition(){return true;}
 List<Target> targets(BotSettings.Snapshot s){return Arrays.asList(new Target(0x12345678),new Target(0x76543210));}
 List<GroundItem> groundItems(BotSettings.Snapshot s){return Collections.emptyList();}
}
