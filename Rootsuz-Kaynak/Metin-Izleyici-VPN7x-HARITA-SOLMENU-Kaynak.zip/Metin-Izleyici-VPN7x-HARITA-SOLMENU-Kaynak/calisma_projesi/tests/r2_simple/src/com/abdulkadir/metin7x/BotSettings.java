package com.abdulkadir.metin7x;
public class BotSettings {
 public static class Snapshot { public boolean collect=false; public int hitMs=10,pvpMs=150; }
 private static final BotSettings INSTANCE=new BotSettings(); private final Snapshot s=new Snapshot();
 public static BotSettings get(android.content.Context c){return INSTANCE;} public Snapshot snapshot(){return s;}
}
