package com.abdulkadir.metin7x;
import java.nio.*;import java.util.*;
import com.github.megatronking.netbare.gateway.*;
public class R2TimingTest {
 static class Event { byte[] data; long at; Event(ByteBuffer b){data=new byte[b.remaining()];b.get(data);at=System.nanoTime();} }
 static final List<Event> events=Collections.synchronizedList(new ArrayList<Event>());
 static class Wire extends Request {
  public String ip(){return "185.128.114.87";} public int port(){return 30001;}
  public void process(ByteBuffer b){if(b.remaining()>1)events.add(new Event(b));}
 }
 static class Reply extends Response {
  public String ip(){return "185.128.114.87";} public int port(){return 30001;} public void process(ByteBuffer b){}
 }
 static void check(boolean b,String m){if(!b)throw new AssertionError(m);}
 static int vid(byte[] b,int start){return ByteBuffer.wrap(b,start,4).order(ByteOrder.LITTLE_ENDIAN).getInt();}
 public static void main(String[] args)throws Exception {
  Attack7x worker=new Attack7x(); Wire wire=new Wire();
  RequestChain outgoing=new RequestChain(wire,Collections.emptyList());
  worker.intercept(outgoing,ByteBuffer.wrap(new byte[]{7}));
  worker.intercept(new ResponseChain(new Reply(),Collections.emptyList()),ByteBuffer.wrap(new byte[]{1}));
  Attack7x.setEnabled(true);
  long deadline=System.currentTimeMillis()+3000;
  while(events.size()<12 && System.currentTimeMillis()<deadline)Thread.sleep(5);
  check(events.size()>=12,"No repeated rounds");
  int before=events.size();
  worker.intercept(outgoing,ByteBuffer.wrap(new byte[]{2})); // normal outgoing/manual activity
  Thread.sleep(180); check(events.size()>before,"Manual activity interrupted worker");
  Attack7x.setEnabled(false);Thread.sleep(100);int stopped=events.size();Thread.sleep(100);
  check(stopped==events.size(),"Packets after stop");
  Event[] sample; synchronized(events){sample=events.toArray(new Event[0]);}
  int pairs=sample.length/2;
  for(int i=0;i<pairs;i++){
   Event select=sample[2*i],attack=sample[2*i+1];
   check(select.data.length==5 && select.data[0]==0x3d,"Selection encoding");
   check(attack.data.length==6 && attack.data[0]==2 && attack.data[1]==0,"Attack encoding");
   int expected=(i%2==0)?0x12345678:0x76543210;
   check(vid(select.data,1)==expected && vid(attack.data,2)==expected,"Target order/VID");
   check(attack.at-select.at>=9_000_000L,"Missing 10ms select-to-attack wait");
   if(i%2==0 && i>0)check(select.at-sample[2*i-1].at>=49_000_000L,"Missing 50ms round wait");
  }
  System.out.println("PASS: R2 bytes, 10ms target wait, 50ms round wait, two-target coverage, manual activity, stop; "+pairs+" hits");
  System.exit(0);
 }
}
