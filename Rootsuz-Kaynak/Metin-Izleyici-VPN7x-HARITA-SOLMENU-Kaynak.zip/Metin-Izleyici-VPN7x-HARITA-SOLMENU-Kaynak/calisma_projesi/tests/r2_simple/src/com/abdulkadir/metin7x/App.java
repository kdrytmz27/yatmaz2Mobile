package com.abdulkadir.metin7x;
public class App extends android.app.Application { public static App current(){return null;} }
