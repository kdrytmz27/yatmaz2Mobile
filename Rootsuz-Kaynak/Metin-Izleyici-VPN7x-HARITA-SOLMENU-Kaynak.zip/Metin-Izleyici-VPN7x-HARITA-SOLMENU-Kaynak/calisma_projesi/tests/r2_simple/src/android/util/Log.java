package android.util;
public class Log { public static int i(String a,String b){return 0;} public static int e(String a,String b,Throwable e){e.printStackTrace();return 0;} }
